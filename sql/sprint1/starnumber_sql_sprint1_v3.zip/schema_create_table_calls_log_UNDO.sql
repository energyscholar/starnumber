-- Table to create calls log

DROP TABLE IF EXISTS STARNUMBER.CALLS_LOG;


commit;


