-- Table to delete table destination_type
-- Created by Bruce

DROP TABLE IF EXISTS STARNUMBER.DESTINATION_TYPE;
commit;
