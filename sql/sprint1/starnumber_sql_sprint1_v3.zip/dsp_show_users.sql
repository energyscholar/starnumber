-- Displays all users

SELECT * FROM STARNUMBER.USERS;


