-- SQL script deletes existing STARNUMBERS table, if it exists.  Tested, of course.
-- Created by Bruce

DROP TABLE IF EXISTS STARNUMBER.STARNUMBERS;
commit;





