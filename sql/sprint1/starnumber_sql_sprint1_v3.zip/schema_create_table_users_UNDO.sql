-- SQL script deletes existing USERS table, if it exists.  Tested, of course.
-- Created by Bruce

DROP TABLE IF EXISTS STARNUMBER.USERS;
commit;





