-- Table to delete phone type
-- Created by Bruce

DROP TABLE IF EXISTS STARNUMBER.REDIRECT_TYPE;


commit;
