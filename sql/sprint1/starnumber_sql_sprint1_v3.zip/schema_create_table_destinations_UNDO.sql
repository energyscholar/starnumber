-- SQL to delete phones table
-- Created by Bruce

DROP TABLE IF EXISTS STARNUMBER.DESTINATIONS;

commit;


